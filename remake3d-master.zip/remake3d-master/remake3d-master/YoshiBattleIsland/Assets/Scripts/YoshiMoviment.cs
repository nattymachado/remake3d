﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YoshiMoviment : MonoBehaviour {

    //public float speed = 1;
    public float speedRotation = 200;
    public float jumpForce = 40;
    private int jumpCount = 0;
    public GameObject yoshi;
    public bool isMoving = false;
    public Quaternion currentRotation;
    public Camera yoshiCamera;
    private Rigidbody yoshRigidbody;

    CharacterController controller;

    public float speed = 6.0f;
    public float jumpSpeed = 8.0f;
    public float gravity = 20.0f;
    public int groundSpeed = 5;
    public int jumpHeight = 1;
    public int airSpeed = 3;

    private Vector3 moveDirection = Vector3.zero;


    void Start()
    {
        controller = GetComponent<CharacterController>();
        
    }

    void Update()
    {
        if (controller.isGrounded)//Check Whether The Character is In Air or not
        {
            moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); // Get Input From User
            moveDirection = transform.TransformDirection(moveDirection);//Specify The Character Movement Direction in world space.
            moveDirection *= speed;//Add Movement Speed To Character.
            if (Input.GetButton("Jump"))//Check For JUMP Button.
                moveDirection.y = jumpSpeed;//Make Character JUMP.
        }
        moveDirection.y -= gravity * Time.deltaTime; //Move Character Down Because Of Gravity That We have assign before.
        controller.Move(moveDirection * Time.deltaTime);//Move The Character in specific Direction.
    }
}
