﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YoshiMoviment : MonoBehaviour {

    public float speed = 1;
    public GameObject yoshi;

    private Rigidbody yoshRigidbody;

   
    void Start()
    {
        yoshRigidbody = yoshi.GetComponent<Rigidbody>();
    }

    public void Update()
    {

        //float h = Input.GetAxis("Horizontal");
        //float v = Input.GetAxis("Vertical");


       

        Move();
    }

    private void Move()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.DownArrow))
        {

            float direction = 1;
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                direction = speed;
            }
            else if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                direction = speed * -1;
            }
            yoshRigidbody.MovePosition(yoshi.transform.position + ( yoshRigidbody.transform.forward * direction));
        } else if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.RightArrow))
        {

            //Acompanha com a o movimento de virada vai em slow com a câmera
            yoshi.transform.Rotate(0, 90, 0);

            Debug.Log(yoshRigidbody.transform.forward);
        }


    }

}
